///////////////////////////////////////////////////////////////////////////////
// shadermanager.h
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#pragma once

#include "ShaderManager.h"
#include "ShapeMeshes.h"

#include <string>
#include <vector>
#include <GL/gl.h> // Ensure OpenGL headers are included
#include <GL/glew.h> // Ensure OpenGL headers are included
#include <glm/glm.hpp> // For glm types

/***********************************************************
 *  SceneManager
 *
 *  This class contains the code for preparing and rendering
 *  3D scenes, including the shader settings.
 ***********************************************************/
class SceneManager
{
public:
	// constructor
	SceneManager(ShaderManager *pShaderManager);
	// destructor
	~SceneManager();
	// properties for loaded texture access

	// set the transformation values 
	// into the transform buffer
	void SetTransformations(
			glm::vec3 scale,
		glm::vec3 XrotationDegrees,
		glm::vec3 YrotationDegrees,
			glm::vec3 ZrotationDegrees,
			glm::vec3 position);

	//std::string materialTag = "m_objectMaterials.tag";

	struct TextureInfo
	{
		GLuint ID;// Texture ID	
		std::string tag;
		//uint32_t ID;
	};
	// properties for object materials
	struct OBJECT_MATERIAL
	{
		float ambientStrength;
		glm::vec3 ambientColor;
		glm::vec3 diffuseColor;
		glm::vec3 specularColor;
		float shininess;
		std::string tag;
	};

private:
	// pointer to shader manager object
	ShaderManager* m_pShaderManager;
	// pointer to basic shapes object
	ShapeMeshes* m_basicMeshes;
	// total number of loaded textures
	int m_loadedTextures;
	// loaded textures info
	TextureInfo m_textureIDs[16];
	// defined object materials
	std::vector<OBJECT_MATERIAL> m_objectMaterials;

	// retrieve defined material by tag
	bool FindMaterial(std::string tag, OBJECT_MATERIAL& material);
	// bind loaded OpenGL textures to slots in memory
	void BindGLTextures();
	void InitializeCustomHalfSphere();
	// load texture images and convert to OpenGL texture data
	bool CreateGLTexture(const char* filename, std::string tag);
	// bind loaded OpenGL textures to slots in memory
	void DestroyGLTextures();
	// find a loaded texture by tag
	int FindTextureID(std::string tag);
	int FindTextureSlot(std::string tag);
	void SetTransformations(glm::vec3 scaleXYZ, float XrotationDegrees, float YrotationDegrees, float ZrotationDegrees, glm::vec3 positionXYZ);
	// find a defined material by tag

	// set the color values into the shader
	void SetShaderColor(
		float redColorValue,
		float greenColorValue,
		float blueColorValue,
		float alphaValue);

	// set the texture data into the shader
	void SetShaderTexture(
		const std::string& textureTag);

	// set the UV scale for the texture mapping
	void SetTextureUVScale(
		float u, float v);

	// set the object material into the shader
	void SetShaderMaterial(
		const std::string& materialTag = "default");

public:

	/*** The following methods are for the students to ***/
	/*** customize for their own 3D scene              ***/
	void PrepareScene();
	void RenderScene();
	// free the loaded OpenGL textures
	// loads textures from image files
	void LoadSceneTextures();
	// pre-set light sources for 3D scene
	void SetupSceneLights();
	// pre-define the object materials for lighting
	void DefineObjectMaterials();
};