﻿///////////////////////////////////////////////////////////////////////////////
// scenemanager.cpp
// ============
// manage the preparing and rendering of 3D scenes - textures, materials, lighting
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
//  Updated by Tricia Ann Sribonma - SNHU Student last on August 24, 2024
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"
#include "ShaderManager.h"
#include <unordered_map> // For storing materials
#include <vector>
#include <cmath>
#include <GL/glew.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>
#include <GL/gl.h>


// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();

	// initialize the texture collection
	for (int i = 0; i < 16; i++)
	{
		m_textureIDs[i].tag = "/0";
		m_textureIDs[i].ID = -1;
	}
	m_loadedTextures = 0;
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	// free up the allocated memory
	m_pShaderManager = NULL;
	if (NULL != m_basicMeshes)
	{
		delete m_basicMeshes;
		m_basicMeshes = NULL;
	}
	// clear the collection of defined materials
	m_objectMaterials.clear();
	// destroy the created OpenGL textures
	DestroyGLTextures();
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);


		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);

		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			stbi_image_free(image);
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}
	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{	// Delete all loaded textures
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glDeleteTextures(1, &m_textureIDs[i].ID);
	}
	// Reset the texture count
	m_loadedTextures = 0;
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationX * rotationY * rotationZ * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue / 255.0f; // Convert to [0, 1] range
	currentColor.g = greenColorValue / 255.0f; // Convert to [0, 1] range
	currentColor.b = blueColorValue / 255.0f; // Convert to [0, 1] range
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		// pass the texture values into shader TAS 08.18.24
		m_pShaderManager->setIntValue("bUseTexture", false);
		// pass the color values into the shader
		m_pShaderManager->setVec4Value("objectColor", currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	const std::string& textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue("bUseTexture", true);

		int textureID = FindTextureSlot(textureTag);
		if (textureID != -1) {
			m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
		}
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/

 /***********************************************************
  *  LoadSceneTextures()
  *
  *  This method is used for preparing the 3D scene by loading
  *  the shapes, textures in memory to support the 3D scene
  *  rendering
  ***********************************************************/

void SceneManager::LoadSceneTextures()
{
	/*** STUDENTS - add the code BELOW for loading the textures that ***/
	/*** will be used for mapping to objects in the 3D scene. Up to  ***/
	/*** 16 textures can be loaded per scene. Refer to the code in   ***/
	/*** the OpenGL Sample for help.                                 ***/

	//Loading and attaching the chosen texture images from the textures folder to set "name to value" for binding seamless textures TAS 08.08.24
	bool bReturn = false;
	bReturn = CreateGLTexture(
		"textures/hardwood.jpg",
		"board"); //Texture for cutting board and handle using a hardwood base texture TAS 08.08.24
	bReturn = CreateGLTexture(
		"textures/damask.jpg",
		"bottle1"); //Texture for oil bottle on left using a *insert* texture TAS 08.08.24
	bReturn = CreateGLTexture(
		"textures/foliage.jpg",
		"bottle2"); //Texture for vinegar bottle on right using a *insert* texture TAS 08.08.24
	bReturn = CreateGLTexture(
		"textures/gold-seamless-texture.jpg",
		"spout"); //Texture for oil and vinegar bottle metallic pourspouts using a *insert* texture TAS 08.08.24
	bReturn = CreateGLTexture(
		"textures/concrete.jpg",
		"mortar"); //Texture for mortar in mortar and pestle set using a *insert* texture TAS 08.08.24
	bReturn = CreateGLTexture(
		"textures/foliage2.jpg",
		"backsplash"); //Texture for backsplash using a simplistic and clean damask texture TAS 08.12.24
	bReturn = CreateGLTexture(
		"textures/tealresin.jpg",
		"bowl2"); //Texture for bowl containing basil herb plant using a *insert* texture TAS 08.12.24
	bReturn = CreateGLTexture(
		"textures/green_leaf_texture.jpeg",
		"bowl"); //Texture for bottom stacked bowl using a simple olive texture TAS 08.12.24
	bReturn = CreateGLTexture(
		"textures/rusticwood.jpg",
		"counter"); //Texture for counter top using a colorful and cracked washed concrete texture TAS 08.12.24

	// after the texture image data is loaded into memory, the
	// loaded textures need to be bound to texture slots - there
	// are a total of 16 available slots for scene textures
	BindGLTextures();
}

/***********************************************************
* DefineObjectMaterials()
*
* This method is used for configuring the various material
* settings for all of the objects in the 3D scene.
* Added by SNHU Student - Tricia Ann Sribonma 08.22.24
***********************************************************/
void SceneManager::DefineObjectMaterials()
{
	OBJECT_MATERIAL goldMaterial;
	goldMaterial.ambientColor = glm::vec3(0.2f, 0.2f, 0.1f);
	goldMaterial.ambientStrength = 0.4f;
	goldMaterial.diffuseColor = glm::vec3(0.3f, 0.3f, 0.2f);
	goldMaterial.specularColor = glm::vec3(0.6f, 0.5f, 0.4f);
	goldMaterial.shininess = 22.0;
	goldMaterial.tag = "gold";
	m_objectMaterials.push_back(goldMaterial);

	OBJECT_MATERIAL cementMaterial;
	cementMaterial.ambientColor = glm::vec3(0.2f, 0.2f, 0.2f);
	cementMaterial.ambientStrength = 0.2f;
	cementMaterial.diffuseColor = glm::vec3(0.5f, 0.5f, 0.5f);
	cementMaterial.specularColor = glm::vec3(0.4f, 0.4f, 0.4f);
	cementMaterial.shininess = 0.5;
	cementMaterial.tag = "cement";
	m_objectMaterials.push_back(cementMaterial);

	OBJECT_MATERIAL woodMaterial;
	woodMaterial.ambientColor = glm::vec3(0.4f, 0.3f, 0.1f);
	woodMaterial.ambientStrength = 0.2f;
	woodMaterial.diffuseColor = glm::vec3(0.3f, 0.2f, 0.1f);
	woodMaterial.specularColor = glm::vec3(0.1f, 0.1f, 0.1f);
	woodMaterial.shininess = 0.3;
	woodMaterial.tag = "wood";
	m_objectMaterials.push_back(woodMaterial);

	OBJECT_MATERIAL tileMaterial;
	tileMaterial.ambientColor = glm::vec3(0.2f, 0.3f, 0.4f);
	tileMaterial.ambientStrength = 0.3f;
	tileMaterial.diffuseColor = glm::vec3(0.3f, 0.2f, 0.1f);
	tileMaterial.specularColor = glm::vec3(0.4f, 0.5f, 0.6f);
	tileMaterial.shininess = 25.0;
	tileMaterial.tag = "tile";
	m_objectMaterials.push_back(tileMaterial);

	OBJECT_MATERIAL glassMaterial;
	glassMaterial.ambientColor = glm::vec3(0.4f, 0.4f, 0.4f);
	glassMaterial.ambientStrength = 0.3f;
	glassMaterial.diffuseColor = glm::vec3(0.3f, 0.3f, 0.3f);
	glassMaterial.specularColor = glm::vec3(0.6f, 0.6f, 0.6f);
	glassMaterial.shininess = 85.0;
	glassMaterial.tag = "glass";
	m_objectMaterials.push_back(glassMaterial);

	OBJECT_MATERIAL clayMaterial;
	clayMaterial.ambientColor = glm::vec3(0.2f, 0.2f, 0.3f);
	clayMaterial.ambientStrength = 0.3f;
	clayMaterial.diffuseColor = glm::vec3(0.4f, 0.4f, 0.5f);
	clayMaterial.specularColor = glm::vec3(0.2f, 0.2f, 0.4f);
	clayMaterial.shininess = 0.5;
	clayMaterial.tag = "clay";
	m_objectMaterials.push_back(clayMaterial);
}

/**********************************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 *  Added by SNHU student - Tricia Ann Sribonma 08.22.24
 **********************************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.ambientColor = m_objectMaterials[index].ambientColor;
			material.ambientStrength = m_objectMaterials[index].ambientStrength;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/******************************************************************
* //SetupSceneLights()
*
* This method is used for adding and configuring the various light
* sources to highlight realism for all of the objects in the 3D scene.
* Added by SNHU Student - Tricia Ann Sribonma 08.22.24
*******************************************************************/
void SceneManager::SetupSceneLights()
{
	// Configure sunlight for a warm, bright effect
	m_pShaderManager->setVec3Value("lightSources[3].position", -10.0f, 1.0f, 0.0f); // Positioned to the far left and high up
	m_pShaderManager->setVec3Value("lightSources[3].ambientColor", 0.17f, 0.17f, 0.17f); // Warm coral color for ambient light
	m_pShaderManager->setVec3Value("lightSources[3].diffuseColor", 0.15f, 0.15f, 0.15f); // Warm coral color for diffuse light
	m_pShaderManager->setVec3Value("lightSources[3].specularColor", 0.2f, 0.2f, 0.2f); // Warm coral color for specular light
	m_pShaderManager->setFloatValue("lightSources[3].focalStrength", 0.033f); // Moderate focal strength
	m_pShaderManager->setFloatValue("lightSources[3].specularIntensity", 0.01f); // High specular intensity for bright rays

	// Define positions for 4 evenly spaced recess lights (high up for diffuse effect)
	float lightPositions[4][3] = {
		{ -5.0f, 20.0f, -5.0f },
		{  5.0f, 20.0f, -5.0f },
		{ -5.0f, 20.0f,  5.0f },
		{  5.0f, 20.0f,  5.0f }
	};

	// Configure each recess light to be less harsh
	for (int i = 0; i < 3; ++i) {
		std::string index = std::to_string(i);
		m_pShaderManager->setVec3Value("lightSources[" + index + "].position", lightPositions[i][0], lightPositions[i][1], lightPositions[i][2]);
		m_pShaderManager->setVec3Value("lightSources[" + index + "].ambientColor", 0.12f, 0.12f, 0.12f); // Softer ambient light
		m_pShaderManager->setVec3Value("lightSources[" + index + "].diffuseColor", 0.2f, 0.2f, 0.33f); // Softer diffuse light
		m_pShaderManager->setVec3Value("lightSources[" + index + "].specularColor", 0.3f, 0.3f, 0.33f); // Softer specular light
		m_pShaderManager->setFloatValue("lightSources[" + index + "].focalStrength", 0.02f); // Low focal strength for diffuse effect
		m_pShaderManager->setFloatValue("lightSources[" + index + "].specularIntensity", 0.02f); // Low specular intensity for diffuse effect
	}

	// Set global ambient light to a high value for overall scene illumination
	m_pShaderManager->setVec3Value("ambientLight", 0.02f, 0.02f, 0.02f); // White light for full illumination

	// Set lighting usage
	m_pShaderManager->setBoolValue("bUseLighting", true);
}

/******************************************************************
* SetShaderMaterial()
*
* This method is used for adding and configuring the various types of
* materials to aid the lighting realism for all of the objects in the 3D scene.
* Added by SNHU Student - Tricia Ann Sribonma 08.22.24
*******************************************************************/
void SceneManager::SetShaderMaterial(const std::string& materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		// find the defined material that matches the tag
		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			// pass the material properties into the shader
			m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
			m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}
/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	// Loads textures for the 3D scene TAS 08.17.24
	LoadSceneTextures();
	// Definitions for objects and materials for 3D scene TAS 08.22.24
	DefineObjectMaterials();
	// Light source settings parameters are defined for 3D scene TAS 08.22.24
	SetupSceneLights();

	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene

	m_basicMeshes->LoadPlaneMesh();// Loading additional shapes to use throughout the project while building objects - TAS 07.20.24
	m_basicMeshes->LoadCylinderMesh(); // For the oil & vinegar containers - TAS 07.20.24
	m_basicMeshes->LoadSphereMesh(); // For the cutting board - TAS 07.20.24
	m_basicMeshes->LoadPrismMesh(); // For the basil leaves - TAS 07.20.24
	m_basicMeshes->LoadConeMesh(); // For the cone - TAS 07.20.24
	m_basicMeshes->LoadTorusMesh(); // For many elements: cutting board, bowls, mortar - TAS 07.20.24
	m_basicMeshes->LoadTaperedCylinderMesh(); // For the bowls & mortar set - TAS 07.20.24
}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{	// Declare textureID
	int textureID;

	// Clear the screen and depth buffer
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	// Activating shaders from fragment and vertex .glsl as necessary when
	// called to be active when applying textures to objects/shapes in the
	// scene TAS 08.22.24
	m_pShaderManager->use();

	// Bind textures
	BindGLTextures();

	// Enable blending and configure it
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	//GLuint shaderProgram = m_pShaderManager->getProgramID(); // Get the shader program ID

	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;
	// Added necessary variables for complete transformations and ensure texture binded properly at all angles TAS 08.12.24
	glm::mat4 scale;
	glm::mat4 rotation;
	glm::mat4 rotation2;
	glm::mat4 translation;
	glm::mat4 model;

	/******************************************************************/
	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.                       ***/
	/******************************************************************/
	// Draw the horizontal plane (base) - TAS 07.20.24
	/******************************************************************/

	scaleXYZ = glm::vec3(20.0f, 10.0f, 5.0f); // Setting object's length, height, and width parameters TAS 08.21.24
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(0.0f, -1.0f, -5.1f); // Slightly below the origin to act as a countertop base for all object to be placed on TAS 07.20.24

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("counter"); // Applying a beautiful wood texture for countertop TAS 08.13.24
	//SetShaderMaterial("wood");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawPlaneMesh();

	// Reset texture matrix
	glMatrixMode(GL_TEXTURE);
	glLoadIdentity();
	glMatrixMode(GL_MODELVIEW);

	/******************************************************************/
	// Draw the vertical plane (background) - TAS 07.20.24
	/******************************************************************/
	scaleXYZ = glm::vec3(20.0f, 20.0f, 10.0f); // Setting object's length, height, and width parameters TAS 08.21.24
	XrotationDegrees = 90.0f; // Rotate around the X-axis to make it vertical TAS 07.20.24
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(0.0f, 9.0f, -10.1f); // Position behind the base plane and all kitchen objects just as a wall/backsplash TAS 07.20.24

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("backsplash"); // Applying foliage texture to wrap plane as a backsplash wall TAS 08.13.24
	SetShaderMaterial("tile");
	SetTextureUVScale(1.0f, 1.0f); // No tiling with this texure TAS 08.13.24
	m_basicMeshes->DrawPlaneMesh();

	// Reset texture matrix
	glMatrixMode(GL_TEXTURE);
	glLoadIdentity();
	glMatrixMode(GL_MODELVIEW);

	/******************************************************************/
	// Draw the sphere cutting board - TAS 07.23.24
	/******************************************************************/
	scaleXYZ = glm::vec3(5.0f, 5.0f, 0.95f);  // Setting object's length, height, and width parameters TAS 08.21.24
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-5.0f, 4.0f, -9.0f); // Left middle of background plane to position in relation to 2D scene TAS 07.23.24

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	//Added "//" in front of shader color to utilize texture instead but leaving this option for further customization possibilities to layer with different techniques TAS 08.13.24
	//SetShaderColor(1.0f, 0.498f, 0.314f, 1.0f); // Coral color chosen for now until I can alter closer to wood color TAS 07.23.24
	SetShaderTexture("board"); // Applying the chose hardwood texture for the cutting board base texture TAS 08.13.24
	SetShaderMaterial("wood");
	SetTextureUVScale(2.0f, 2.0f); // Applying a 2x2 tiling effect TAS 08.13.24
	m_basicMeshes->DrawSphereMesh();

	// Reset texture matrix and blending state
	glMatrixMode(GL_TEXTURE);
	glLoadIdentity();
	glMatrixMode(GL_MODELVIEW);

	// Setting opacity using ShaderManager
	//float opacity = 0.5f; // Declaring opacity for 2nd texture TAS 08.22.24
	//m_pShaderManager->setFloatValue("blendFactor", opacity); // Set the blend factor TAS 08.22.24

	/******************************************************************/
	// Draw the torus handle on the cutting board - TAS 07.23.24
	/******************************************************************/

	scaleXYZ = glm::vec3(0.85f, 0.85f, 1.50f); // Setting object's length, height, and width parameters TAS 08.21.24
	XrotationDegrees = 180.0f; // Rotate to make the torus vertical TAS 07.23.24
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-5.0f, 9.50f, -9.0f); // To float on top of the sphere cutting board TAS 07.23.24

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	//Added "//" in front of shader color to utilize texture instead but leaving this option for further customization possibilities to layer with different techniques TAS 08.13.24
	//SetShaderColor(1.0f, 0.498f, 0.314f, 1.0f); // Coral color to match cutting board for now TAS 07.23.24
	SetShaderTexture("board"); // Applying the chose hardwood texture for the cutting board base texture TAS 08.13.24
	SetShaderMaterial("wood");
	SetTextureUVScale(2.0f, 2.0f); // Applying a 2x2 tiling effect TAS 08.13.24
	m_basicMeshes->DrawTorusMesh();

	// Reset texture matrix and blending state
	glMatrixMode(GL_TEXTURE);
	glLoadIdentity();
	glMatrixMode(GL_MODELVIEW);

	// Reset blending state after drawing
	glDisable(GL_BLEND);

	/******************************************************************/
	// Draw the top of the 2 stacked bowls - TAS 08.13.24
	/******************************************************************/
	scaleXYZ = glm::vec3(1.35f, 2.77f, 1.50f); // Setting object's length, height, and width parameters TAS 08.21.24
	XrotationDegrees = 180.0f; // Rotate to make the intended top bowl vertically upright TAS 07.23.24
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-7.7f, 3.30f, -6.0f); // To place far left of all objects same relation to 2D scene TAS 08.13.24

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("bowl"); // Applying a green texture for the top stacked bowl TAS 08.13.24
	SetShaderMaterial("tile");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawHalfSphereMesh();

	// Reset texture matrix and blending state
	glMatrixMode(GL_TEXTURE);
	glLoadIdentity();
	glMatrixMode(GL_MODELVIEW);

	// Reset blending state after drawing
	glDisable(GL_BLEND);

	/******************************************************************/
	// Draw the bottom of the 2 stacked bowls - TAS 08.13.24
	/******************************************************************/
	scaleXYZ = glm::vec3(1.35f, 2.55f, 1.50f); // Setting object's length, height, and width parameters TAS 08.21.24
	XrotationDegrees = 180.0f; // Rotate to make the intended bottom bowl vertically upright TAS 07.23.24
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-7.7f, 1.60f, -6.0f); // To place far left of all objects same relation to 2D scene TAS 08.13.24

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("bowl2"); // Applying a fun ombre concrete texture for the bottom stacked bowl TAS 08.13.24
	SetShaderMaterial("tile");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawTaperedCylinderMesh();

	// Reset texture matrix and blending state
	glMatrixMode(GL_TEXTURE);
	glLoadIdentity();
	glMatrixMode(GL_MODELVIEW);

	// Reset blending state after drawing
	glDisable(GL_BLEND);

	/******************************************************************/
	// Draw the oil bottle (left) of the 2 bottles - TAS 08.13.24
	/******************************************************************/
	scaleXYZ = glm::vec3(0.84f, 4.00f, 1.0f); // Setting object's length, height, and width parameters TAS 08.21.24
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-4.7f, -0.95f, -7.0f); // Trying to place in relation to 2D scene infront of cutting board but to the left of the 2nd bottle TAS 08.13.24

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("bottle1"); // Applying a gray damask texture for the left oil bottle TAS 08.13.24
	SetShaderMaterial("clay");
	SetTextureUVScale(2.0f, 2.0f); // Setting texture to tile 2x2 TAS 08.13.24
	m_basicMeshes->DrawCylinderMesh();

	// Reset texture matrix and blending state
	glMatrixMode(GL_TEXTURE);
	glLoadIdentity();
	glMatrixMode(GL_MODELVIEW);

	// Reset blending state after drawing
	glDisable(GL_BLEND);

	/**************************************************************************/
	// Draw the base neck of oil bottle (left) of the 2 bottles - TAS 08.13.24
	/**************************************************************************/
	scaleXYZ = glm::vec3(0.84f, 0.50f, 1.0f); // Setting object's length, height, and width parameters TAS 08.21.24
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-4.7f, 3.0f, -7.0f); // Setting on bottle base at top TAS 08.13.24

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(192, 192, 192, 1); // Gray color to match the damask color of the bottle TAS 08.13.24
	SetShaderMaterial("clay");
	SetTextureUVScale(1.0f, 1.0f); // No tiling effect TAS 08.13.24
	m_basicMeshes->DrawTaperedCylinderMesh();

	// Reset texture matrix and blending state
	glMatrixMode(GL_TEXTURE);
	glLoadIdentity();
	glMatrixMode(GL_MODELVIEW);

	// Reset blending state after drawing
	glDisable(GL_BLEND);

	/**************************************************************************/
	// Draw the neck of oil bottle (left) of the 2 bottles - TAS 08.13.24
	/**************************************************************************/
	scaleXYZ = glm::vec3(0.40f, 0.95f, 0.40f); // Setting object's length, height, and width parameters TAS 08.21.24
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-4.7f, 3.5f, -7.0f); // Placing above neck base TAS 08.13.24

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(192, 192, 192, 1); // Gray color to match the damask color of the bottle TAS 08.13.24
	SetShaderMaterial("clay");
	SetTextureUVScale(1.0f, 1.0f); // No tiling for this texture, set at standard parameters TAS 08.13.24
	m_basicMeshes->DrawCylinderMesh();

	// Reset texture matrix and blending state
	glMatrixMode(GL_TEXTURE);
	glLoadIdentity();
	glMatrixMode(GL_MODELVIEW);

	// Reset blending state after drawing
	glDisable(GL_BLEND);

	/**************************************************************************/
	// Draw the rim of oil bottle (left) of the 2 bottles - TAS 08.13.24
	/**************************************************************************/
	scaleXYZ = glm::vec3(0.45f, 0.45f, 0.45f); // Setting object's length, height, and width parameters TAS 08.21.24
	XrotationDegrees = 90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-4.7f, 4.52f, -7.0f); // Rim will sit petruding slightly over neck to connect pour spout TAS 08.13.24

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(192, 192, 192, 1); // Gray color to match the damask color of the bottle TAS 08.13.24
	SetShaderMaterial("clay");
	SetTextureUVScale(1.0f, 1.0f); // No tiling for this texture, set at standard parameters TAS 08.13.24
	m_basicMeshes->DrawTorusMesh();

	// Reset texture matrix and blending state
	glMatrixMode(GL_TEXTURE);
	glLoadIdentity();
	glMatrixMode(GL_MODELVIEW);

	// Reset blending state after drawing
	glDisable(GL_BLEND);

	/**************************************************************************/
	// Draw the spout of oil bottle (left) of the 2 bottles - TAS 08.17.24
	/**************************************************************************/
	scaleXYZ = glm::vec3(0.15f, 1.5f, 0.15f); // Setting object's length, height, and width parameters TAS 08.21.24
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-4.7f, 4.44f, -7.0f); // Sitting on the highest point of oil bottle just below cover cap TAS 08.17.24

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("spout"); // Applying a metallic gold pattern texture for the left bottle spoout for oil TAS 08.13.24
	SetShaderMaterial("gold");
	SetTextureUVScale(1.0f, 1.0f); // No tiling for this texture, set at standard parameters TAS 08.17.24
	m_basicMeshes->DrawCylinderMesh();

	// Reset texture matrix and blending state
	glMatrixMode(GL_TEXTURE);
	glLoadIdentity();
	glMatrixMode(GL_MODELVIEW);

	// Reset blending state after drawing
	glDisable(GL_BLEND);

	/***************************************************************************************/
	// Draw the bottom of spout cover of oil bottle (left) of the 2 bottles - TAS 08.17.24
	/***************************************************************************************/
	scaleXYZ = glm::vec3(0.16f, 0.16f, 0.55f); // Setting object's length, height, and width parameters TAS 08.21.24
	XrotationDegrees = 90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-4.7f, 4.77f, -7.0f); // Placing towards bottom of pour spout TAS 08.17.24

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(0, 0, 0, 1); // Black color to match 2D scene TAS 08.13.24
	SetShaderMaterial("glass");
	SetTextureUVScale(1.0f, 1.0f); // No tiling for this texture, set at standard parameters TAS 08.17.24
	m_basicMeshes->DrawTorusMesh();

	// Reset texture matrix and blending state
	glMatrixMode(GL_TEXTURE);
	glLoadIdentity();
	glMatrixMode(GL_MODELVIEW);

	// Reset blending state after drawing
	glDisable(GL_BLEND);

	/******************************************************************************************/
	// Draw the connector of spout cover of oil bottle (left) of the 2 bottles - TAS 08.17.24
	/******************************************************************************************/
	scaleXYZ = glm::vec3(0.55f, 0.5f, 0.5f); // Setting object's length, height, and width parameters TAS 08.21.24
	XrotationDegrees = 180.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = -90.0f;
	positionXYZ = glm::vec3(-4.7f, 5.25f, -7.0f); // Connecting pour spout cover to o-ring bottom on pour spout TAS 08.17.24

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(0, 0, 0, 1); // Black color to match 2D scene TAS 08.13.24
	SetShaderMaterial("glass");
	SetTextureUVScale(1.0f, 1.0f); // No tiling for this texture, set at standard parameters TAS 08.17.24
	m_basicMeshes->DrawHalfTorusMesh();

	// Reset texture matrix and blending state
	glMatrixMode(GL_TEXTURE);
	glLoadIdentity();
	glMatrixMode(GL_MODELVIEW);

	// Reset blending state after drawing
	glDisable(GL_BLEND);

	/************************************************************************************/
	// Draw the top of spout cover of oil bottle (left) of the 2 bottles - TAS 08.17.24
	/************************************************************************************/
	scaleXYZ = glm::vec3(0.17f, 0.55f, 0.17f); // Setting object's length, height, and width parameters TAS 08.21.24
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-4.7f, 5.55f, -7.0f); // Placing at top of pour spout to cover tip as a cap TAS 08.17.24

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(0, 0, 0, 1); // Black color to match 2D scene TAS 08.13.24
	SetShaderMaterial("glass");
	SetTextureUVScale(1.0f, 1.0f); // No tiling for this texture, set at standard parameters TAS 08.17.24
	m_basicMeshes->DrawCylinderMesh();

	// Reset texture matrix and blending state
	glMatrixMode(GL_TEXTURE);
	glLoadIdentity();
	glMatrixMode(GL_MODELVIEW);

	// Reset blending state after drawing
	glDisable(GL_BLEND);

	/******************************************************************/
	// Draw the vinegar bottle (right) of the 2 bottles - TAS 08.13.24
	/******************************************************************/
	scaleXYZ = glm::vec3(0.84f, 4.00f, 1.0f); // Setting object's length, height, and width parameters TAS 08.21.24
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-2.79f, -0.95f, -7.0f); // Placing 2nd bottle for vinegar to the right of the oil bottle drawn above TAS 08.13.24

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("bottle2"); // Applying a simplistic foliage pattern texture for the right bottle for vinegar TAS 08.13.24
	SetShaderMaterial("clay");
	SetTextureUVScale(1.0f, 1.0f); // No tiling for this texture, set at standard parameters TAS 08.13.24
	m_basicMeshes->DrawCylinderMesh();

	// Reset texture matrix and blending state
	glMatrixMode(GL_TEXTURE);
	glLoadIdentity();
	glMatrixMode(GL_MODELVIEW);

	// Reset blending state after drawing
	glDisable(GL_BLEND);

	/**************************************************************************/
	// Draw the base neck of vinegar bottle (right) of the 2 bottles - TAS 08.13.24
	/**************************************************************************/
	scaleXYZ = glm::vec3(0.84f, 0.50f, 1.0f); // Setting object's length, height, and width parameters TAS 08.21.24
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-2.79f, 3.0f, -7.0f); // Placed on top of bottle's body as a base for the neck and pour spout TAS 08.13.24

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(0, 128, 0, 1); // Dark green color to match the foliage color of the bottle TAS 08.13.24
	SetShaderMaterial("clay");
	SetTextureUVScale(1.0f, 1.0f); // No tiling for this texture, set at standard parameters TAS 08.13.24
	m_basicMeshes->DrawTaperedCylinderMesh();

	// Reset texture matrix and blending state
	glMatrixMode(GL_TEXTURE);
	glLoadIdentity();
	glMatrixMode(GL_MODELVIEW);

	// Reset blending state after drawing
	glDisable(GL_BLEND);

	/**************************************************************************/
	// Draw the neck of vinegar bottle (right) of the 2 bottles - TAS 08.13.24
	/**************************************************************************/
	scaleXYZ = glm::vec3(0.40f, 0.95f, 0.40f); // Setting object's length, height, and width parameters TAS 08.21.24
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-2.79f, 3.5f, -7.0f); // Acting as a connector between the body-base and pour spout TAS 08.13.24

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(0, 128, 0, 1); // Dark green color to match the foliage color of the bottle TAS 08.13.24
	SetShaderMaterial("clay");
	SetTextureUVScale(1.0f, 1.0f); // No tiling for this texture, set at standard parameters TAS 08.13.24
	m_basicMeshes->DrawCylinderMesh();

	// Reset texture matrix and blending state
	glMatrixMode(GL_TEXTURE);
	glLoadIdentity();
	glMatrixMode(GL_MODELVIEW);

	// Reset blending state after drawing
	glDisable(GL_BLEND);

	/**************************************************************************/
	// Draw the rim of vinegar bottle (right) of the 2 bottles - TAS 08.13.24
	/**************************************************************************/
	scaleXYZ = glm::vec3(0.45f, 0.45f, 0.45f); // Setting object's length, height, and width parameters TAS 08.21.24
	XrotationDegrees = 90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-2.79f, 4.52f, -7.0f); // Slightly petruding over neck to "catch" spills from pour spout TAS 08.13.24

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(0, 128, 0, 1); // Dark green color to match the foliage color of the bottle TAS 08.13.24
	SetShaderMaterial("clay");
	SetTextureUVScale(1.0f, 1.0f); // No tiling for this texture, set at standard parameters TAS 08.13.24
	m_basicMeshes->DrawTorusMesh();

	// Reset texture matrix and blending state
	glMatrixMode(GL_TEXTURE);
	glLoadIdentity();
	glMatrixMode(GL_MODELVIEW);

	// Reset blending state after drawing
	glDisable(GL_BLEND);

	/****************************************************************************/
	// Draw the spout of vinegar bottle (right) of the 2 bottles - TAS 08.17.24
	/****************************************************************************/
	scaleXYZ = glm::vec3(0.15f, 1.5f, 0.15f); // Setting object's length, height, and width parameters TAS 08.21.24
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-2.79f, 4.44f, -7.0f); // Top of vinegar bottle TAS 08.17.24

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("spout"); // Applying a metallic gold pattern texture for the right bottle spoout for vinegar TAS 08.13.24
	SetShaderMaterial("gold");
	SetTextureUVScale(1.0f, 1.0f); // No tiling for this texture, set at standard parameters TAS 08.17.24
	m_basicMeshes->DrawCylinderMesh();

	// Reset texture matrix and blending state
	glMatrixMode(GL_TEXTURE);
	glLoadIdentity();
	glMatrixMode(GL_MODELVIEW);

	// Reset blending state after drawing
	glDisable(GL_BLEND);

	/********************************************************************************************/
	// Draw the bottom of spout cover of vinegar bottle (right) of the 2 bottles - TAS 08.17.24
	/********************************************************************************************/
	scaleXYZ = glm::vec3(0.16f, 0.16f, 0.55f); // Setting object's length, height, and width parameters TAS 08.21.24
	XrotationDegrees = 90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-2.79f, 4.77f, -7.0f); // Sitting just above bottom of pour spout TAS 08.17.24

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(0, 0, 0, 1); // Black color to match 2D scene TAS 08.13.24
	SetShaderMaterial("glass");
	SetTextureUVScale(1.0f, 1.0f); // No tiling for this texture, set at standard parameters TAS 08.17.24
	m_basicMeshes->DrawTorusMesh();

	// Reset texture matrix and blending state
	glMatrixMode(GL_TEXTURE);
	glLoadIdentity();
	glMatrixMode(GL_MODELVIEW);

	// Reset blending state after drawing
	glDisable(GL_BLEND);

	/***********************************************************************************************/
	// Draw the connector of spout cover of vinegar bottle (right) of the 2 bottles - TAS 08.17.24
	/***********************************************************************************************/
	scaleXYZ = glm::vec3(0.55f, 0.5f, 0.5f); // Setting object's length, height, and width parameters TAS 08.21.24
	XrotationDegrees = 180.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = -90.0f;
	positionXYZ = glm::vec3(-2.77f, 5.25f, -7.0f); // Connects o-ring of spout cover and spout cap TAS 08.17.24

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(0, 0, 0, 1); // Black color to match 2D scene TAS 08.13.24
	SetShaderMaterial("tile");
	SetTextureUVScale(1.0f, 1.0f); // No tiling for this texture, set at standard parameters TAS 08.17.24
	m_basicMeshes->DrawHalfTorusMesh();

	// Reset texture matrix and blending state
	glMatrixMode(GL_TEXTURE);
	glLoadIdentity();
	glMatrixMode(GL_MODELVIEW);

	// Reset blending state after drawing
	glDisable(GL_BLEND);

	/*****************************************************************************************/
	// Draw the top of spout cover of vinegar bottle (right) of the 2 bottles - TAS 08.17.24
	/*****************************************************************************************/
	scaleXYZ = glm::vec3(0.17f, 0.55f, 0.17f); // Setting object's length, height, and width parameters TAS 08.21.24
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-2.77f, 5.55f, -7.0f); // Capping top of pour spout TAS 08.17.24

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(0, 0, 0, 1); // Black color to match 2D scene TAS 08.13.24
	SetShaderMaterial("tile");
	SetTextureUVScale(1.0f, 1.0f); // No tiling for this texture, set at standard parameters TAS 08.17.24
	m_basicMeshes->DrawCylinderMesh();

	// Reset texture matrix and blending state
	glMatrixMode(GL_TEXTURE);
	glLoadIdentity();
	glMatrixMode(GL_MODELVIEW);

	// Reset blending state after drawing
	glDisable(GL_BLEND);

	/******************************************************************/
	// Draw the mortar bowl - TAS 08.13.24
	/******************************************************************/
	scaleXYZ = glm::vec3(2.22f, 2.20f, 1.70f); // Setting object's length, height, and width parameters TAS 08.21.24
	XrotationDegrees = 180.0f; // Rotate to make the intended bottom bowl vertically upright TAS 07.23.24
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-1.75f, 1.60f, -4.0f); // To place far left of all objects same relation to 2D scene TAS 08.13.24

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("mortar"); // Applying a fun ombre concrete texture for the bottom stacked bowl TAS 08.13.24
	SetShaderMaterial("tile");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawHalfSphereMesh();

	// Reset texture matrix and blending state
	glMatrixMode(GL_TEXTURE);
	glLoadIdentity();
	glMatrixMode(GL_MODELVIEW);

	// Reset blending state after drawing
	glDisable(GL_BLEND);
}